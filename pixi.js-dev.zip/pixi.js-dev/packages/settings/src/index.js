export * from './settings';
export { default as isMobile } from 'ismobilejs';
