# @pixi/sprite-animated

## Installation

```bash
npm install @pixi/sprite-animated
```

## Usage

```js
import '@pixi/sprite-animated';
```