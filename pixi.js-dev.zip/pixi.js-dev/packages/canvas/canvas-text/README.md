# @pixi/canvas-text

## Installation

```bash
npm install @pixi/canvas-text
```

## Usage

```js
import '@pixi/canvas-text';
```