# @pixi/sprite

## Installation

```bash
npm install @pixi/sprite
```

## Usage

```js
import { Sprite } from '@pixi/sprite';

const sprite = new Sprite();
```