# @pixi/filter-displacement

## Installation

```bash
npm install @pixi/filter-displacement
```

## Usage

```js
import '@pixi/filter-displacement';
```